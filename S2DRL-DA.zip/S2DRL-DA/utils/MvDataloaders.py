import numpy as np
from torch.utils.data import DataLoader, TensorDataset
import torch
import scipy.io as scio
from sklearn.decomposition import PCA


def preprocess(data, target_dim=1024):
    num_samples, current_dim = data.shape
    if current_dim < target_dim:
        padded_data = np.pad(data, ((0, 0), (0, target_dim - current_dim)), mode='constant', constant_values=0)
        return padded_data
    elif current_dim > target_dim:
        pca = PCA(n_components=target_dim)
        reduced_data = pca.fit_transform(data)
        return reduced_data
    else:
        return data


def Get_dataloaders(batch_size=128, path_to_data='./utils/DATA/', DATANAME='MNIST-Sobel.mat', target_dim=1024):
    """Dataloader with (32, 32) images, ensuring all views are processed to target_dim."""
    DATA = scio.loadmat(path_to_data + DATANAME)
    view = len(DATA) - 3 - 1  # 判断视图数量
    X1 = DATA['X1']
    X2 = DATA['X2']


    X1 = X1.reshape(X1.shape[0], -1)
    X2 = X2.reshape(X2.shape[0], -1)

    X1 = preprocess(X1, target_dim)
    X2 = preprocess(X2, target_dim)
    if view == 3:
        X3 = DATA['X3']
        X3 = X3.reshape(X3.shape[0], -1)
        X3 = preprocess(X3, target_dim)

    X1 = X1.reshape(-1, 1, 32, 32)
    X2 = X2.reshape(-1, 1, 32, 32)
    if view == 3:
        X3 = X3.reshape(-1, 1, 32, 32)

    y = DATA['Y']
    size = y.shape[1]
    print("Number of samples:", size)
    cluster = np.unique(y)
    print('Cluster K: ' + str(len(cluster)))

    x1 = torch.from_numpy(X1).float()
    x2 = torch.from_numpy(X2).float()
    if view == 3:
        x3 = torch.from_numpy(X3).float()
    y = torch.from_numpy(y[0])

    # 创建 TensorDataset
    if view == 2:
        dataset = TensorDataset(x1, x2, y)
    elif view == 3:
        dataset = TensorDataset(x1, x2, x3, y)

    # DataLoader
    train_loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
    return train_loader, view, len(cluster), size

