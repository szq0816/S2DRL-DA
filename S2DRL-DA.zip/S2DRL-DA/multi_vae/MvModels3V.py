import torch
from torch import nn
from torch.nn import functional as F
from pydantic import BaseModel
from multi_vae import helpers
import torch as th
import numpy as np
from typing import Tuple, List, Union, Optional

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
EPS = 1e-12
from torch.nn.parameter import Parameter


class Config(BaseModel):
    @property
    def class_name(self):
        return self.__class__.__name__


class Backbone(nn.Module):
    def __init__(self):
        """
        Backbone base class
        """
        super().__init__()
        self.layers = nn.ModuleList()

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x


class MlpConfig(Config):
    # Shape of the input
    input_size: Tuple[int, ...] = None
    # Units in the network layers
    layers: Tuple[Union[int, str], ...] = (512, 512, 256)
    # Activation function. Can be a single string specifying the activation function for all layers, or a list/tuple of
    # string specifying the activation function for each layer.
    activation: Union[str, None, List[Union[None, str]], Tuple[Union[None, str], ...]] = "relu"
    # Include bias parameters? A single bool for all layers, or a list/tuple of booleans for individual layers.
    use_bias: Union[bool, Tuple[bool, ...]] = True
    # Include batch norm after layers? A single bool for all layers, or a list/tuple of booleans for individual layers.
    use_bn: Union[bool, Tuple[bool, ...]] = False


class MLP(Backbone):
    def __init__(self, input_size=None):
        """
        MLP backbone

        :param cfg: MLP config
        :type cfg: config.defaults.MLP
        :param input_size: Optional input size which overrides the one set in `cfg`.
        :type input_size: Optional[Union[List, Tuple]]
        :param _:
        :type _:
        """
        super().__init__()
        self.output_size = self.create_linear_layers(self.layers, input_size=input_size)

    @staticmethod
    def get_activation_module(a):
        if a == "relu":
            return nn.ReLU()
        elif a == "sigmoid":
            return nn.Sigmoid()
        elif a == "tanh":
            return nn.Tanh()
        elif a == "softmax":
            return nn.Softmax(dim=1)
        elif a.startswith("leaky_relu"):
            neg_slope = float(a.split(":")[1])
            return nn.LeakyReLU(neg_slope)
        else:
            raise RuntimeError(f"Invalid MLP activation: {a}.")

    @classmethod
    def create_linear_layers(cls, layer_container, input_size=None):
        # `input_size` takes priority over `cfg.input_size`
        if input_size is not None:
            output_size = list(input_size)
        else:
            output_size = list((1, 28, 28))

        if len(output_size) > 1:
            layer_container.append(nn.Flatten())
            output_size = [np.prod(output_size)]

        n_layers = len((512, 512, 256))
        activations = helpers.ensure_iterable("relu", expected_length=n_layers)
        use_bias = helpers.ensure_iterable(True, expected_length=n_layers)
        use_bn = helpers.ensure_iterable(False, expected_length=n_layers)

        for n_units, act, _use_bias, _use_bn in zip((512, 512, 256), activations, use_bias, use_bn):
            # If we get n_units = -1, then the number of units should be the same as the previous number of units, or
            # the input dim.
            if n_units == -1:
                n_units = output_size[0]

            layer_container.append(nn.Linear(in_features=output_size[0], out_features=n_units, bias=_use_bias))
            if _use_bn:
                # Add BN before activation
                layer_container.append(nn.BatchNorm1d(num_features=n_units))
            if act is not None:
                # Add activation
                layer_container.append(cls.get_activation_module(act))
            output_size[0] = n_units

        return output_size


class Discriminator(nn.Module):
    def __init__(self, input_size):
        """


        :param cfg: Discriminator config
        :type cfg: config.eamc.defaults.Discriminator
        :param input_size: Input size
        :type input_size: Union[List[int, ...], Tuple[int, ...], ...]
        """
        super().__init__()
        ipt = [256]
        self.mlp = MLP(input_size=ipt)
        self.output_layer = nn.Sequential(
            nn.Linear(self.mlp.output_size[0], 1, bias=True),
            nn.Sigmoid()
        )

    def forward(self, x0, xv):
        d0 = self.output_layer(self.mlp(x0.to(device)))
        dv = self.output_layer(self.mlp(xv.to(device)))
        return [d0, dv]





class AttentionLayer(nn.Module):
    def __init__(self, input_size):
        """
        EAMC attention net

        :param cfg: Attention config
        :type cfg: config.eamc.defaults.AttentionLayer
        :param input_size: Input size
        :type input_size: Union[List[int, ...], Tuple[int, ...], ...]
        """
        super().__init__()
        self.tau = 10.0
        # MLP = MLP(layers=(100, 50), activation=None), input_size = 1000
        ipt = [768]
        self.mlp = MLP(input_size=ipt, )
        self.output_layer = nn.Linear(self.mlp.output_size[0], 3, bias=True)
        self.weights = None

    def forward(self, xs):
        h = th.cat(xs, dim=1)
        act = self.output_layer(self.mlp(h))
        e = nn.functional.softmax(th.sigmoid(act) / self.tau, dim=1)
        # e = nn.functional.softmax(act, dim=1)
        self.weights = th.mean(e, dim=0)
        return self.weights


class VAE(nn.Module):
    def __init__(self, img_size, latent_spec, temperature=.67,
                 use_cuda=False, view_num=2, Network='C',
                 hidden_dim=256, shareAE=1):
        """
        Class which defines model and forward pass.

        Parameters
        ----------
        img_size : tuple of ints
            Size of images. E.g. (1, 32, 32)

        latent_spec : dict
            Specifies latent distribution.

        temperature : float
            Temperature for gumbel softmax distribution.

        use_cuda : bool
            If True moves model to GPU
        """
        super(VAE, self).__init__()
        self.use_cuda = use_cuda

        # Parameters
        self.img_size = img_size
        self.is_continuous = 'cont' in latent_spec
        self.is_discrete = 'disc' in latent_spec
        self.latent_spec = latent_spec

        self.view_num = view_num
        self.MvLatent_spec = {'disc': latent_spec['disc']}
        for i in range(self.view_num):
            continue_name = 'cont' + str(i + 1)
            self.MvLatent_spec[continue_name] = latent_spec['cont']

        self.Net = Network
        self.share = shareAE
        if self.Net == 'C':
            self.num_pixels = []
            for i in range(self.view_num):
                self.num_pixels.append(img_size[1] * img_size[2])

        self.temperature = temperature
        self.hidden_dim = hidden_dim  # Hidden dimension of linear layer
        self.reshape = (64, 4, 4)  # Shape required to start transpose convs

        # Calculate dimensions of latent distribution
        self.latent_cont_dim = 0
        self.latent_disc_dim = 0
        self.num_disc_latents = 0
        if self.is_continuous:
            self.latent_cont_dim = self.latent_spec['cont']
        if self.is_discrete:
            self.latent_disc_dim += sum([dim for dim in self.latent_spec['disc']])
            self.num_disc_latents = len(self.latent_spec['disc'])
        self.latent_dim = self.latent_cont_dim + self.latent_disc_dim

        if self.Net == 'C':
            Mv_img_to_features = []
            Mv_features_to_hidden = []
            Mv_latent_to_features = []
            Mv_features_to_img = []
            # Define encoder layers
            for i in range(self.view_num):
                # Intial layer
                encoder_layers = [
                    nn.Conv2d(self.img_size[0], 32, (4, 4), stride=2, padding=1),
                    nn.ReLU()
                ]
                # Add additional layer if (64, 64) images
                if self.img_size[1:] == (64, 64):
                    encoder_layers += [
                        nn.Conv2d(32, 32, (4, 4), stride=2, padding=1),
                        nn.ReLU()
                    ]
                elif self.img_size[1:] == (32, 32):
                    # (32, 32) images are supported but do not require an extra layer
                    pass
                else:
                    raise RuntimeError(
                        "{} sized images not supported. Only (None, 32, 32) and (None, 64, 64) supported. Build your own architecture or reshape images!".format(
                            img_size))
                # Add final layers
                encoder_layers += [
                    nn.Conv2d(32, 64, (4, 4), stride=2, padding=1),
                    nn.ReLU(),
                    nn.Conv2d(64, 64, (4, 4), stride=2, padding=1),
                    nn.ReLU()
                ]
                # Define encoder
                Mv_img_to_features.append(nn.Sequential(*encoder_layers))
                # Map encoded features into a hidden vector which will be used to
                # encode parameters of the latent distribution
                features_to_hidden = nn.Sequential(
                    nn.Linear(64 * 4 * 4, self.hidden_dim),
                    nn.ReLU()
                    # nn.Sigmoid()
                )
                Mv_features_to_hidden.append(features_to_hidden)

            if self.share:
                self.Mv_img_to_features = nn.ModuleList([Mv_img_to_features[0]])
                self.Mv_features_to_hidden = nn.ModuleList([Mv_features_to_hidden[0]])
            else:
                self.Mv_img_to_features = nn.ModuleList(Mv_img_to_features)
                self.Mv_features_to_hidden = nn.ModuleList(Mv_features_to_hidden)
            # Encode parameters of latent distribution
            means = []
            log_vars = []
            if self.is_continuous:
                for i in range(self.view_num):
                    means.append(nn.Linear(self.hidden_dim, self.latent_cont_dim))
                    log_vars.append(nn.Linear(self.hidden_dim, self.latent_cont_dim))
            self.means = nn.ModuleList(means)
            self.log_vars = nn.ModuleList(log_vars)
            if self.is_discrete:
                # Linear layer for each of the categorical distributions
                fc_alphas = []
                for disc_dim in self.latent_spec['disc']:
                    fc_alphas.append(nn.Linear(self.hidden_dim * self.view_num, disc_dim))
                self.fc_alphas = nn.ModuleList(fc_alphas)

            for i in range(self.view_num):
                # Map latent samples to features to be used by generative model
                latent_to_features = nn.Sequential(
                    nn.Linear(self.latent_dim, self.hidden_dim),
                    nn.ReLU(),
                    nn.Linear(self.hidden_dim, 64 * 4 * 4),
                    nn.ReLU()
                )
                Mv_latent_to_features.append(latent_to_features)
                # Define decoder
                decoder_layers = []
                # Additional decoding layer for (64, 64) images
                if self.img_size[1:] == (64, 64):
                    decoder_layers += [
                        nn.ConvTranspose2d(64, 64, (4, 4), stride=2, padding=1),
                        nn.ReLU()
                    ]

                decoder_layers += [
                    nn.ConvTranspose2d(64, 32, (4, 4), stride=2, padding=1),
                    nn.ReLU(),
                    nn.ConvTranspose2d(32, 32, (4, 4), stride=2, padding=1),
                    nn.ReLU(),
                    nn.ConvTranspose2d(32, self.img_size[0], (4, 4), stride=2, padding=1),
                    nn.Sigmoid()
                    # nn.Tanh()
                ]
                # Define decoder
                Mv_features_to_img.append(nn.Sequential(*decoder_layers))

            if self.share:
                self.Mv_latent_to_features = nn.ModuleList([Mv_latent_to_features[0]])
                self.Mv_features_to_img = nn.ModuleList([Mv_features_to_img[0]])
            else:
                self.Mv_latent_to_features = nn.ModuleList(Mv_latent_to_features)
                self.Mv_features_to_img = nn.ModuleList(Mv_features_to_img)

        self.Discriminators = nn.ModuleList([Discriminator(input_size=500).to(device) for _ in range(2)])

        self.attention = AttentionLayer(input_size=500)
        self.fc_fu = nn.Linear(256, 768)

        self.cluster_layer = Parameter(torch.Tensor(10, 768))
        torch.nn.init.xavier_normal_(self.cluster_layer.data)
        self.cluster_layer1 = Parameter(torch.Tensor(10, 256))
        torch.nn.init.xavier_normal_(self.cluster_layer1.data)

    def encode(self, X):
        """
        Encodes an image into parameters of a latent distribution defined in
        self.latent_spec.

        Parameters
        ----------
        x : torch.Tensor
            Batch of data, shape (N, C, H, W)
        """
        batch_size = X[0].size()[0]
        features = []
        hiddens = []
        for i in range(self.view_num):
            # Encode image to hidden features
            if self.share:
                net_num = 0
            else:
                net_num = i
            # print(X[i].shape)
            features.append(self.Mv_img_to_features[net_num](X[i]))
            hiddens.append(self.Mv_features_to_hidden[net_num](features[i].view(batch_size, -1)))

        weights = self.attention(hiddens)

        discriminator_outputs = [self.Discriminators[i](hiddens[0], hiddens[i + 1]) for i in range(len(hiddens) - 1)]
        # fusion = torch.cat(hiddens, dim=1)
        # fusion = self.fc_fu(hiddens)
        fusion = th.sum(weights * th.stack(hiddens, dim=-1), dim=-1)
        # fusion = th.sum(weights * th.stack(hiddens, dim=-1), dim=-1)
        fusion = self.fc_fu(fusion)

        # print(hiddens.shape)
        # print(fusion.shape)
        # Output parameters of latent distribution from hidden representation
        latent_dist = {}
        if self.is_continuous:
            for i in range(self.view_num):
                continue_name = 'cont' + str(i + 1)
                latent_dist[continue_name] = [self.means[i](hiddens[i]), self.log_vars[i](hiddens[i])]
        if self.is_discrete:
            latent_dist['disc'] = []
            for fc_alpha in self.fc_alphas:
                latent_dist['disc'].append(F.softmax(fc_alpha(fusion), dim=1))

        return latent_dist, discriminator_outputs, fusion, hiddens

    def reparameterize(self, latent_dist):
        """
        Samples from latent distribution using the reparameterization trick.

        Parameters
        ----------
        latent_dist : dict
            Dict with keys 'cont' or 'disc' or both, containing the parameters
            of the latent distributions as torch.Tensor instances.
        """
        latent_sample = []
        if self.is_continuous:
            for i in range(self.view_num):
                countinus_name = 'cont' + str(i + 1)
                mean, logvar = latent_dist[countinus_name]
                cont_sample = self.sample_normal(mean, logvar)
                latent_sample.append(cont_sample)

        if self.is_discrete:
            for alpha in latent_dist['disc']:
                disc_sample = self.sample_gumbel_softmax(alpha)
                latent_sample.append(disc_sample)

        # Concatenate continuous and discrete samples into one large sample
        return torch.cat(latent_sample, dim=1)

    def sample_normal(self, mean, logvar):
        """
        Samples from a normal distribution using the reparameterization trick.

        Parameters
        ----------
        mean : torch.Tensor
            Mean of the normal distribution. Shape (N, D) where D is dimension
            of distribution.

        logvar : torch.Tensor
            Diagonal log variance of the normal distribution. Shape (N, D)
        """
        if self.training:
            std = torch.exp(0.5 * logvar)
            eps = torch.zeros(std.size()).normal_()
            if self.use_cuda:
                eps = eps.cuda()
            return mean + std * eps
        else:
            # Reconstruction mode
            return mean

    def sample_gumbel_softmax(self, alpha):
        """
        Samples from a gumbel-softmax distribution using the reparameterization
        trick.

        Parameters
        ----------
        alpha : torch.Tensor
            Parameters of the gumbel-softmax distribution. Shape (N, D)
        """
        if self.training:
            # Sample from gumbel distribution
            unif = torch.rand(alpha.size())
            if self.use_cuda:
                unif = unif.cuda()
            gumbel = -torch.log(-torch.log(unif + EPS) + EPS)
            # Reparameterize to create gumbel softmax sample
            log_alpha = torch.log(alpha + EPS)
            logit = (log_alpha + gumbel) / self.temperature
            return F.softmax(logit, dim=1)
        else:
            # In reconstruction mode, pick most likely sample
            _, max_alpha = torch.max(alpha, dim=1)
            one_hot_samples = torch.zeros(alpha.size())
            # On axis 1 of one_hot_samples, scatter the value 1 at indices
            # max_alpha. Note the view is because scatter_ only accepts 2D
            # tensors.
            one_hot_samples.scatter_(1, max_alpha.view(-1, 1).data.cpu(), 1)
            if self.use_cuda:
                one_hot_samples = one_hot_samples.cuda()
            return one_hot_samples

    def decode(self, latent_samples):
        """
        Decodes sample from latent distribution into an image.

        Parameters
        ----------
        latent_sample : torch.Tensor
            Sample from latent distribution.
        """
        features_to_img = []
        for i in range(self.view_num):
            if self.share:
                net_num = 0
            else:
                net_num = i
            feature = self.Mv_latent_to_features[net_num](latent_samples[i])
            if self.Net == 'C':
                features_to_img.append(self.Mv_features_to_img[net_num](feature.view(-1, *self.reshape)))
        return features_to_img[:]

    def forward(self, X):
        """
        Forward pass of model.

        Parameters
        ----------
        x : torch.Tensor
            Batch of data. Shape (N, C, H, W)
        """
        latent_dist, discriminator_outputs, fusion, hiddens = self.encode(X)
        # print(latent_dist)
        latent_sample = self.reparameterize(latent_dist)
        # print(latent_sample.shape)
        split_list = []
        for i in range(self.view_num):
            split_list.append(self.latent_spec['cont'])
        split_list.append(self.latent_spec['disc'][0])
        cont_des_list = latent_sample.split(split_list, dim=1)
        decode_list = []
        for i in range(self.view_num):
            decode_list.append(torch.cat([cont_des_list[i], cont_des_list[-1]], dim=1))
        out_list = self.decode(decode_list)
        q = 1.0 / (1.0 + torch.sum(
            torch.pow(fusion.unsqueeze(1).to(device) - self.cluster_layer.to(device), 2), 2) / 1).to(device)
        q = q.pow((1 + 1.0) / 2.0)
        q = (q.t() / torch.sum(q, 1)).t()

        q1 = 1.0 / (1.0 + torch.sum(
            torch.pow(hiddens[0].unsqueeze(1).to(device) - self.cluster_layer1.to(device), 2), 2) / 1).to(device)
        q1 = q1.pow((1 + 1.0) / 2.0)
        q1 = (q1.t() / torch.sum(q1, 1)).t()

        q2 = 1.0 / (1.0 + torch.sum(
            torch.pow(hiddens[1].unsqueeze(1).to(device) - self.cluster_layer1.to(device), 2), 2) / 1).to(device)
        q2 = q2.pow((1 + 1.0) / 2.0)
        q2 = (q2.t() / torch.sum(q2, 1)).t()

        q3 = 1.0 / (1.0 + torch.sum(
            torch.pow(hiddens[2].unsqueeze(1).to(device) - self.cluster_layer1.to(device), 2), 2) / 1).to(device)
        q3 = q3.pow((1 + 1.0) / 2.0)
        q3 = (q3.t() / torch.sum(q3, 1)).t()

        return out_list, latent_dist, discriminator_outputs, q1, q2, q3, q


def target_distribution(q):
    weight = q ** 2 / q.sum(0)
    return (weight.t() / weight.sum(1)).t()
