from pydantic import BaseModel


class Configg(BaseModel):
    @property
    def class_name(self):
        return self.__class__.__name__

