import torch.nn as nn








class CNN(Backbone):
    def __init__(self, cfg, flatten_output=True, **_):
        """
        CNN backbone

        :param cfg: CNN config
        :type cfg: config.defaults.CNN
        :param flatten_output: Flatten the backbone output?
        :type flatten_output: bool
        :param _:
        :type _:
        """
        super().__init__()

        self.output_size = list(cfg.input_size)

        for layer_type, *layer_params in cfg.layers:
            if layer_type == "conv":
                self.layers.append(nn.Conv2d(in_channels=self.output_size[0], out_channels=layer_params[2],
                                             kernel_size=layer_params[:2]))
                # Update output size
                self.output_size[0] = layer_params[2]
                self.output_size[1:] = helpers.conv2d_output_shape(self.output_size[1:], kernel_size=layer_params[:2])
                # Add activation
                if layer_params[3] == "relu":
                    self.layers.append(nn.ReLU())

            elif layer_type == "pool":
                self.layers.append(nn.MaxPool2d(kernel_size=layer_params))
                # Update output size
                self.output_size[1:] = helpers.conv2d_output_shape(self.output_size[1:], kernel_size=layer_params,
                                                                   stride=layer_params)

            elif layer_type == "relu":
                self.layers.append(nn.ReLU())

            elif layer_type == "lrelu":
                self.layers.append(nn.LeakyReLU(layer_params[0]))

            elif layer_type == "bn":
                if len(self.output_size) > 1:
                    self.layers.append(nn.BatchNorm2d(num_features=self.output_size[0]))
                else:
                    self.layers.append(nn.BatchNorm1d(num_features=self.output_size[0]))

            elif layer_type == "fc":
                self.layers.append(nn.Flatten())
                self.output_size = [np.prod(self.output_size)]
                self.layers.append(nn.Linear(self.output_size[0], layer_params[0], bias=True))
                self.output_size = [layer_params[0]]

            else:
                raise RuntimeError(f"Unknown layer type: {layer_type}")

        if flatten_output:
            self.layers.append(nn.Flatten())
            self.output_size = [np.prod(self.output_size)]





class Backbones(nn.Module):
    BACKBONE_CONSTRUCTORS = {
        "CNN": CNN,
        "MLP": MLP
    }

    def __init__(self, backbone_configs, flatten_output=True):
        """
        Class representing multiple backbones. Call with list of inputs, where inputs[0] goes into the first backbone,
        and so on.

        :param backbone_configs: List of backbone configs. Each element corresponds to a backbone.
        :type backbone_configs: List[Union[config.defaults.MLP, config.defaults.CNN], ...]
        :param flatten_output: Flatten the backbone outputs?
        :type flatten_output: bool
        """
        super().__init__()

        self.backbones = nn.ModuleList()
        for cfg in backbone_configs:
            self.backbones.append(self.create_backbone(cfg, flatten_output=flatten_output))

    @property
    def output_sizes(self):
        return [bb.output_size for bb in self.backbones]

    @classmethod
    def create_backbone(cls, cfg, flatten_output=True):
        if cfg.class_name not in cls.BACKBONE_CONSTRUCTORS:
            raise RuntimeError(f"Invalid backbone: '{cfg.class_name}'")
        return cls.BACKBONE_CONSTRUCTORS[cfg.class_name](cfg, flatten_output=flatten_output)

    def forward(self, views):
        assert len(views) == len(self.backbones), f"n_views ({len(views)}) != n_backbones ({len(self.backbones)})."
        outputs = [bb(v) for bb, v in zip(self.backbones, views)]
        return outputs


