from .test import *
from .mnist import *
from .ccv import *
from .voc import *
from .rgbd import *
from .fmnist import *
from .coil import *
